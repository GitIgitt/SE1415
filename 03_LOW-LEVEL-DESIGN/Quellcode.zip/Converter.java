/* 
   
 */


class Converter {


    public final toJpg() {
    
    }

    public final toPng() {
    
    }

    public final toPdf() {
    
    }


}
