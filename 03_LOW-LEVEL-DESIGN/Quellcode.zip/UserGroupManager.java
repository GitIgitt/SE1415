/* 
   
 */


class UserGroupManager {


    public final UserGroup[] getAll() {
    
    }

    public final UserGroup getUserGroup(String id) {
    
    }

    public final User[] getMembers() {
    
    }

    public final deleteMember(User user) {
    
    }

    public final User getCreator() {
    
    }

    public final String getName() {
    
    }

    public final postName(String name) {
    
    }

    public final postMember(User user) {
    
    }

    public final deleteUserGroup() {
    
    }


}
