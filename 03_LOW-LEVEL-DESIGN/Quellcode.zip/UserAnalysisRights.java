/* 
   
 */


class UserAnalysisRights {

    private User owner;
    private AtmoCalcAnalysis data;


}
