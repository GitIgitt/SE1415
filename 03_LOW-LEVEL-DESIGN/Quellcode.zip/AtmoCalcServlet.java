/* 
   
 */


abstract class AtmoCalcServlet {


    protected abstract void doAtmoCalcGet(AtmoCalcServletRequest req, AtmoCalcServletResponse resp) {
    
    }

    protected abstract void doAtmoCalcDelete(AtmoCalcServletRequest req, AtmoCalcServletResponse resp) {
    
    }

    protected abstract void doAtmoCalcPost(AtmoCalServletRequest req, AtmoCalcServletResponse resp) {
    
    }

    protected abstract void doAtmoCalcPut(AtmoCalcServletRquest req, AtmoCalcServletResponse resp) {
    
    }

    protected final void doGet(AtmoCalcServletRequest req, AtmoCalcServletResponse resp) {
    
    }

    protected final void doDelete(AtmoCalcServletResponse req, AtmoCalcServletResponse resp) {
    
    }

    protected final void doPost(AtmoCalcServletRequest req, AtmoCalcServletResponse resp) {
    
    }

    protected final void doPut(AtmoCalServletRequest req, AtmoCalcServletResponse resp) {
    
    }


}
