/* 
   
 */


abstract class AtmoCalcAnalyse {


    public abstract String getFullName() {
    
    }

    public abstract ACData analyse(ACData data) {
    
    }

    public abstract boolean breakAnalyse() {
    
    }


}
