/* 
   
 */


class UserDataRights {

    private User owner;
    private ACData data;


}
