/* 
   
 */


class UserGroupAccessor {


    public final String getUserGroup() {
    
    }

    public final String getUser() {
    
    }

    public final deleteMember() {
    
    }

    public final String getName() {
    
    }

    public final postName() {
    
    }


}
