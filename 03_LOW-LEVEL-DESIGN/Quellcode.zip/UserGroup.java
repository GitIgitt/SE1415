/* 
   
 */


class UserGroup {

    private String id;
    private String name;
    private User creator;

    public final addUser(User user) {
    
    }

    public final removeUser(User user) {
    
    }


}
