/* 
   
 */


class AnalyseAccessor {


    public final ACData getData(String dataID) {
    
    }

    public final String[] getAllAnalysis() {
    
    }

    public final boolean putData(ACData data) {
    
    }

    public final boolean postData(ACData data, String dataID) {
    
    }


}
