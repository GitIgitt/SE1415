/* 
   
 */


class Dataset {

    private CSV data;

    /*
     * wird in Konstruktor durch Systemzeit gesetzt
     */

    public Date uploadDate;
    public String id;


}
