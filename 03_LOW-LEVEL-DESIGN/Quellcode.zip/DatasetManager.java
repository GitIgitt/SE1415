/* 
   
 */


class DatasetManager {


    public final putOwnerID(String datasetID, String ownerID) {
    
    }

    public final String getOwnerID(String datasetID) {
    
    }

    public final Date getUploadDate(String datasetID) {
    
    }

    public final String getID(String ownerID, Date uploadDate) {
    
    }

    public final Dataset getDataset(String datasetID) {
    
    }

    public final deleteDataset(String datasetID) {
    
    }


}
