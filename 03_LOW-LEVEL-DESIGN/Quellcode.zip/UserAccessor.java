/* 
   
 */


class UserAccessor {


    public final String getUser(String id) {
    
    }

    public final putUser() {
    
    }

    public final deleteUser() {
    
    }

    public final postFirstname() {
    
    }

    public final postLastname() {
    
    }

    public final postEmail() {
    
    }

    public final postPassword() {
    
    }

    public final postProfilePicture() {
    
    }


}
