/* 
   
 */


class AnalyzedData {

    public Date creationDate;
    public String ownerID;
    public String datasetID;
    public Date lastModified;
    public String lastModifiedBy;
    public String id;


}
