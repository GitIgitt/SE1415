/* 
   
 */


class AnalyzedDataAccessor {



}
