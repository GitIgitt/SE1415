/* 
   
 */


class AnalyseManager {

    private AnalyseAccessor analyseAccessor;

    public final AtmoCalcAnalyse[] getAll() {
    
    }

    public final saveData(ACData data, String dataID) {
    
    }

    public final AtmoCalcAnalyse getAnalyse() {
    
    }

    public final boolean startAnalysis(String analyseID, ACData dataID, String userID) {
    
    }

    public final () {
    
    }


}
