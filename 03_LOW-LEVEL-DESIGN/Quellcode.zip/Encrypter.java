/* 
   
 */


class Encrypter {


    public final String encrypt(String original) {
    
    }


}
