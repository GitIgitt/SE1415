/* 
   
 */


class AnalyzedDataManager {


    public final putOwnerID(String ownerID) {
    
    }

    public final putDatasetID(String datasetID) {
    
    }

    public final Date getCreationDate(String analyzedDataID) {
    
    }

    public final String getOwnerID(String analyzedDataID) {
    
    }

    public final getLastModified(String analyzedDataID) {
    
    }

    public final postLastModified( analyzedDataID) {
    
    }

    public final postLastModifiedBy(String ownerID,  analyzedDataID) {
    
    }

    public final getLastModifiedBy(String analyzedDataID) {
    
    }

    public final deleteAnalyzedData(String analyzedDataID) {
    
    }

    public final convert(String filetype) {
    
    }


}
