/* 
   
 */


abstract class UserRights {

    public User owner;
    public  data;

    public final boolean checkRights() {
    
    }


}
