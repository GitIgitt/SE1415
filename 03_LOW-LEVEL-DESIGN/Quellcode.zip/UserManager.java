/* 
   
 */


class UserManager {


    public final User[] getAll() {
    
    }

    public final User getUser(String id) {
    
    }

    public final UserGroup[] getAllUserGroups() {
    
    }

    public final putUser(String firstname, String lastname, String email, String password) {
    
    }

    public final postFirstname(String newFirstname) {
    
    }

    public final postLastname(String newLastname) {
    
    }

    public final String postEmail(String newEmail) {
    
    }

    public final postPassword(String newPassword) {
    
    }

    public final postProfilePicture(Image profilePicture) {
    
    }

    public final deleteUser(User user) {
    
    }


}
